package com.ssafy.happyhouse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BooTestApplicationTests {

	@Test
	void contextLoads() {
	}
	
	@Test
	void sidocode() {
		
	}

}

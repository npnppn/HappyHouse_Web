# 사용법

1. Uploads의 csv 파일을 `C:\ProgramData\MySQL\MySQL Server 8.0\Uploads` 에 놓는다.
2. happyhousedb.sql 을 실행한다.
3. happyhouse_basic_dump.sql을 실행한다.




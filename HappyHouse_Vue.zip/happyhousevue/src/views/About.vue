<template>
  <div>
    <b-carousel
      id="carousel-1"
      v-model="slide"
      :interval="4000"
      controls
      indicators
      background="#ababab"
      width="300"
      height="300"
      max-width="300"
      max-height="300"
      style="text-shadow: 1px 1px 2px #333"
      @sliding-start="onSlideStart"
      @sliding-end="onSlideEnd"
    >
      <!-- Text slides with image -->
      <b-carousel-slide
        caption="홈킷리스트"
        text="원하는 지역의 아파트를 검색해보세요!"
        style="text-align: left; font-size: 30px; height: 70vh"
        img-src="https://i.ibb.co/3vNDnyn/0D9A0304.jpg"
        img-width="300"
        img-height="300"
      ></b-carousel-slide>

      <!-- Slides with custom text -->
      <b-carousel-slide
        img-src="https://images.unsplash.com/photo-1494512163437-5d01c88c0e5a?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80"
      >
      </b-carousel-slide>

      <!-- Slides with image only -->
      <b-carousel-slide
        img-src="https://images.unsplash.com/photo-1616737725885-98ef1e4e467b?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1328&q=80"
      ></b-carousel-slide>

      <!-- Slides with img slot -->
      <!-- Note the classes .d-block and .img-fluid to prevent browser default image alignment -->
      <b-carousel-slide>
        <template #img>
          <img
            class="d-block img-fluid w-100"
            src="https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80"
            alt="image slot"
          />
        </template>
      </b-carousel-slide>
    </b-carousel>

    <b-container class="bv-example-row mt-4 mb-4">
      <b-row align-h="center" class="mt-4 mb-4"><h2>팀원 소개</h2></b-row>
      <b-row align-h="center">
        <b-col md="auto" class="mr-2">
          <b-card
            img-src="https://i.ibb.co/0hrRsnj/Kakao-Talk-20210527-140346694.jpg"
            img-alt="Card image"
            img-top
            img-width="100"
            img-height="400"
            align="center"
            style="max-width: 20rem"
          >
            <b-card-text> 박형민 </b-card-text>
            <b-card-text> 백엔드(Springboot) </b-card-text>
          </b-card>
        </b-col>
        <b-col md="auto" class="ml-2">
          <b-card
            img-src="https://i.ibb.co/M8BFrnT/image.jpg"
            img-alt="Card image"
            img-top
            img-width="100"
            img-height="400"
            align="center"
            style="max-width: 20rem"
          >
            <b-card-text> 금아현 </b-card-text>
            <b-card-text> 프론트엔드(Vue.js) </b-card-text>
          </b-card>
        </b-col>
      </b-row>
    </b-container>
  </div>
</template>

<script>
export default {
  data() {
    return {
      slide: 0,
      sliding: null,
    };
  },
  methods: {
    onSlideStart() {
      this.sliding = true;
    },
    onSlideEnd() {
      this.sliding = false;
    },
  },
};
</script>

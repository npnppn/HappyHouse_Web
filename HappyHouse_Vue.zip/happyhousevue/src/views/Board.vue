<template>
  <div>
    <b-container class="bv-example-row">
      <router-view/>
    </b-container>
  </div>
</template>

<script>
export default {
  name: 'Board',
  components: {
  },
  data() {
    return {};
  },
  methods: {},
};
</script>

<style></style>
